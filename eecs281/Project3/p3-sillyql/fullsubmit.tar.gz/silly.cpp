// Project Identifier: C0F4DFE8B340D81183C208F70F9D2D797908754D

#include <algorithm>
#include <cassert>
#include <deque>
#include <functional>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include <getopt.h>
#include <stdio.h>
#include "TableEntry.h"

using namespace std;

class dataFrame {
public:
	dataFrame() : columnNum(0), hashed(""), columnType(0), columnName(0), hash(0) {}
	dataFrame(int n) : columnNum(n), hashed(""), columnType(0), columnName(0), hash(0) {}
	int columnNum;
	string hashed;
	vector<vector<TableEntry>> table;
	vector<char> columnType;
	vector<string> columnName;
	unordered_map<string, int> columnIndex;
	unordered_multimap<TableEntry, int> hash;
	multimap<TableEntry, int, less<TableEntry>> bst;
};

static unordered_map<string, dataFrame> sql;
bool quiet = false;

void create() {
	string Tname;
	int Tsize;
	cin >> Tname >> Tsize;
	// if foundable, then directly return
	auto iter = sql.find(Tname);
	if (iter != sql.end()) {
		cout << "Error during CREATE: Cannot create already existing table " << Tname << "\n";
		string trash;
		getline(cin, trash);
		return;
	}
	cout << "New table " << Tname << " with column(s)";
	sql.emplace(Tname, dataFrame(Tsize));
	sql[Tname].columnType.reserve(Tsize);
	sql[Tname].table.reserve(Tsize);
	sql[Tname].columnName.reserve(Tsize);
	sql[Tname].hash.reserve(Tsize);
	string colType;
	for (int i = 0; i < Tsize; ++i) {
		cin >> colType;
		if (colType == "bool") {
			sql[Tname].columnType.push_back('b');
		}
		else if (colType == "int") {
			sql[Tname].columnType.push_back('i');
		}
		else if (colType == "double") {
			sql[Tname].columnType.push_back('d');
		}
		else if (colType == "string") {
			sql[Tname].columnType.push_back('s');
		}
	}
	string colName;
	for (int i = 0; i < Tsize; ++i) {
		cin >> colName;
		sql[Tname].columnName.push_back(colName);
		sql[Tname].columnIndex[colName] = i;
		cout << " " << colName;
	}
	cout << " created\n";
}

void remove() {
	string Tname;
	cin >> Tname;
	auto iter = sql.find(Tname);
	if (iter == sql.end()) {
		cout << "Error during REMOVE: " << Tname << " does not name a table in the database\n";
		string trash;
		getline(cin, trash);
		return;
	}
	sql.erase(iter);
	cout << "Table " << Tname << " deleted\n";
}

void insert() {
	string trash;
	string Tname;
	int length;
	cin >> trash >> Tname >> length;
	cin >> trash;
	auto iter = sql.find(Tname);
	if (iter == sql.end()) {
		cout << "Error during INSERT: " << Tname << " does not name a table in the database\n";
		/*for (int i = 0; i < length; ++i) {
			getline(cin, trash);
		}*/
		getline(cin, trash);
		return;
	}
	size_t originLength = iter->second.table.size();
	cout << "Added " << length << " rows to " << Tname << " from position " << originLength << " to " << (length + originLength - 1) << "\n";
	for (int i = 0; i < length; ++i) {
		vector<TableEntry> row;
		row.reserve(iter->second.columnNum);
		for (int j = 0; j < iter->second.columnNum; ++j) {
			if (iter->second.columnType[j] == 'b') {
				bool element;
				cin >> element;
				row.push_back(TableEntry(element));
			}
			else if (iter->second.columnType[j] == 'i') {
				int element;
				cin >> element;
				row.push_back(TableEntry(element));
			}
			else if (iter->second.columnType[j] == 'd') {
				double element;
				cin >> element;
				row.push_back(TableEntry(element));
			}
			else if (iter->second.columnType[j] == 's') {
				string element;
				cin >> element;
				row.push_back(TableEntry(element));
			}
		}
		iter->second.table.push_back(row);
	}
	if (iter->second.hashed == "") {
		return;
	}
	auto iterCol = find(iter->second.columnName.begin(), iter->second.columnName.end(), iter->second.hashed);
	size_t indexCol = distance(iter->second.columnName.begin(), iterCol);
	if (!iter->second.hash.empty()) {
		iter->second.hash.clear();
		for (size_t i = 0; i < iter->second.table.size(); ++i) {
			iter->second.hash.emplace(iter->second.table[i][indexCol], (int)i);
		}
	}
	else {
		iter->second.bst.clear();
		for (size_t i = 0; i < iter->second.table.size(); ++i) {
			iter->second.bst.emplace(iter->second.table[i][indexCol], (int)i);
		}
	}
}

void print() {
	string trash;
	string Tname;
	string colName;
	string mode;
	int length;
	vector<string> columns;
	vector<int> indices;
	cin >> trash >> Tname >> length;
	auto iter = sql.find(Tname);
	if (iter == sql.end()) {
		cout << "Error during PRINT: " << Tname << " does not name a table in the database\n";
		getline(cin, trash);
		return;
	}
	for (int i = 0; i < length; ++i) {
		cin >> colName;
		auto iterCol = find(iter->second.columnName.begin(), iter->second.columnName.end(), colName);
		if (iterCol == iter->second.columnName.end()) {
			cout << "Error during PRINT: " << colName << " does not name a column in " << Tname << "\n";
			getline(cin, trash);
			return;
		}
		columns.push_back(colName);
		indices.push_back(iter->second.columnIndex[colName]);
	}
	cin >> mode;
	if (mode == "ALL") {
		if (quiet) {
			cout << "Printed " << iter->second.table.size() << " matching rows from " << Tname << "\n";
			return;
		}
		for (int i = 0; i < length; ++i) {
			cout << columns[i] << " ";
		}
		cout << "\n";
		for (size_t i = 0; i < iter->second.table.size(); ++i) {
			for (int j = 0; j < length; ++j) {
				cout << iter->second.table[i][indices[j]] << " ";
			}
			cout << "\n";
		}
		cout << "Printed " << iter->second.table.size() << " matching rows from " << Tname << "\n";
		return;
	}
	char opt;
	int rowNum = 0;
	cin >> colName >> opt;
	auto iterCol = find(iter->second.columnName.begin(), iter->second.columnName.end(), colName);
	size_t indexCol = distance(iter->second.columnName.begin(), iterCol);
	if (iterCol == iter->second.columnName.end()) {
		cout << "Error during PRINT: " << colName << " does not name a column in " << Tname << "\n";
		getline(cin, trash);
		return;
	}
	if (!quiet) {
		for (int i = 0; i < length; ++i) {
			cout << columns[i] << " ";
		}
		cout << "\n";
	}
	if (iter->second.columnType[indexCol] == 'b') {
		bool condition;
		cin >> condition;
		if (opt == '=') {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] == TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] == TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
		else if (opt == '<') {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] < TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] < TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
		else {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] > TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] > TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
	}
	else if (iter->second.columnType[indexCol] == 'i') {
		int condition;
		cin >> condition;
		if (opt == '=') {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] == TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] == TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
		else if (opt == '<') {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] < TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] < TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
		else {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] > TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] > TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
	}
	else if (iter->second.columnType[indexCol] == 'd') {
		double condition;
		cin >> condition;
		if (opt == '=') {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] == TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] == TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
		else if (opt == '<') {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] < TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] < TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
		else {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] > TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] > TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
	}
	else {
		string condition;
		cin >> condition;
		if (opt == '=') {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] == TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] == TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
		else if (opt == '<') {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] < TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] < TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
		else {
			if (!iter->second.bst.empty() && iter->second.hashed == colName) {
				for (auto it = iter->second.bst.begin(); it != iter->second.bst.end(); ++it) {
					if (iter->second.table[it->second][indexCol] > TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << iter->second.table[it->second][indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
			else {
				for (auto it = iter->second.table.begin(); it != iter->second.table.end(); ++it) {
					if ((*it)[indexCol] > TableEntry(condition)) {
						if (!quiet) {
							for (int i = 0; i < length; ++i) {
								cout << (*it)[indices[i]] << " ";
							}
							cout << "\n";
						}
						++rowNum;
					}
				}
			}
		}
	}
	cout << "Printed " << rowNum << " matching rows from " << Tname << "\n";
	return;
}

void delete_() {
	string trash;
	string Tname;
	char opt;
	string colName;
	cin >> trash >> Tname;
	cin >> trash >> colName >> opt;
	auto iter = sql.find(Tname);
	if (iter == sql.end()) {
		cout << "Error during DELETE: " << Tname << " does not name a table in the database\n";
		getline(cin, trash);
		return;
	}
	auto iterCol = find(iter->second.columnName.begin(), iter->second.columnName.end(), colName);
	size_t indexCol = distance(iter->second.columnName.begin(), iterCol);
	if (iterCol == iter->second.columnName.end()) {
		cout << "Error during DELETE: " << colName << " does not name a column in " << Tname << "\n";
		getline(cin, trash);
		return;
	}
	size_t originSize = iter->second.table.size();
	if (iter->second.columnType[indexCol] == 'b') {
		bool condition;
		cin >> condition;
		if (opt == '=') {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] == TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] == TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
		else if (opt == '<') {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] < TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] < TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
		else {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] > TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] > TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
	}
	else if (iter->second.columnType[indexCol] == 'i') {
		int condition;
		cin >> condition;
		if (opt == '=') {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] == TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] == TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
		else if (opt == '<') {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] < TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] < TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
		else {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] > TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] > TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
	}
	else if (iter->second.columnType[indexCol] == 'd') {
		double condition;
		cin >> condition;
		if (opt == '=') {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] == TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] == TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
		else if (opt == '<') {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] < TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] < TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
		else {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] > TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] > TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
	}
	else {
		string condition;
		cin >> condition;
		if (opt == '=') {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] == TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] == TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
		else if (opt == '<') {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] < TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] < TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
		else {
			iter->second.table.erase(remove_if(iter->second.table.begin(), iter->second.table.end(), [&](const vector<TableEntry> a)->bool {return a[indexCol] > TableEntry(condition); }), iter->second.table.end());
			/*for (auto it = iter->second.table.cbegin(); it != iter->second.table.cend(); ) {
				if ((*it)[indexCol] > TableEntry(condition)) {
					it == iter->second.table.erase(it);
				}
				else {
					++it;
				}
			}*/
		}
	}
	cout << "Deleted " << (originSize - iter->second.table.size()) << " rows from " << Tname << "\n";
	if (iter->second.hashed == "") {
		return;
	}
	auto hashCol = find(iter->second.columnName.begin(), iter->second.columnName.end(), iter->second.hashed);
	size_t indexHash = distance(iter->second.columnName.begin(), hashCol);
	if (!iter->second.hash.empty()) {
		iter->second.hash.clear();
		for (size_t i = 0; i < iter->second.table.size(); ++i) {
			iter->second.hash.emplace(iter->second.table[i][indexHash], (int)i);
		}
	}
	else {
		iter->second.bst.clear();
		for (size_t i = 0; i < iter->second.table.size(); ++i) {
			iter->second.bst.emplace(iter->second.table[i][indexHash], (int)i);
		}
	}
}

void join() {
	string table1;
	string table2;
	string trash;
	string colName1;
	string colName2;
	int length;
	//JOIN <tablename1> AND <tablename2> WHERE <colname1> = <colname2> AND PRINT <N> <print_colname1> <1 | 2> <print_colname2> <1 | 2> ... <print_colnameN> <1 | 2>
	cin >> table1 >> trash;
	cin >> table2 >> trash;
	cin >> colName1 >> trash;
	cin >> colName2 >> trash;
	cin >> trash >> length;
	auto iter1 = sql.find(table1);
	auto iter2 = sql.find(table2);
	if (iter1 == sql.end()) {
		cout << "Error during JOIN: " << table1 << " does not name a table in the database\n";
		getline(cin, trash);
		return;
	}
	if (iter2 == sql.end()) {
		cout << "Error during JOIN: " << table2 << " does not name a table in the database\n";
		getline(cin, trash);
		return;
	}
	auto iterCol1 = find(iter1->second.columnName.begin(), iter1->second.columnName.end(), colName1);
	auto iterCol2 = find(iter2->second.columnName.begin(), iter2->second.columnName.end(), colName2);
	if (iterCol1 == iter1->second.columnName.end()) {
		cout << "Error during JOIN: " << colName1 << " does not name a column in " << table1 << "\n";
		getline(cin, trash);
		return;
	}
	if (iterCol2 == iter2->second.columnName.end()) {
		cout << "Error during JOIN: " << colName2 << " does not name a column in " << table2 << "\n";
		getline(cin, trash);
		return;
	}
	int which;
	string colName;
	string Tname;
	vector<string> columns;
	vector<bool> tables;
	for (int i = 0; i < length; ++i) {
		cin >> colName >> which;
		if (which == 1) {
			Tname = table1;
		}
		else {
			Tname = table2;
		}
		auto iterCol = find(sql[Tname].columnName.begin(), sql[Tname].columnName.end(), colName);
		if (iterCol == sql[Tname].columnName.end()) {
			cout << "Error during JOIN: " << colName << " does not name a column in " << Tname << "\n";
			getline(cin, trash);
			return;
		}
		columns.push_back(colName);
		tables.push_back(Tname == table1);
	}
	unordered_map<TableEntry, vector<int>> map2;
	size_t index1 = distance(iter1->second.columnName.begin(), iterCol1);
	size_t index2 = distance(iter2->second.columnName.begin(), iterCol2);
	for (size_t i = 0; i < iter2->second.table.size(); ++i) {
		map2[iter2->second.table[i][index2]].push_back((int)i);
	}
	if (!quiet) {
		for (int i = 0; i < length; ++i) {
			cout << columns[i] << " ";
		}
		cout << "\n";
	}
	int rowNum = 0;
	for (size_t i = 0; i < iter1->second.table.size(); ++i) {
		auto iter = map2.find(iter1->second.table[i][index1]);
		if (iter == map2.end()) {
			continue;
		}
		for (size_t j = 0; j < iter->second.size(); ++j) {
			if (!quiet) {
				int Rindex = iter->second[j];
				for (int k = 0; k < length; ++k) {
					if (tables[k] == true) {
						int index = sql[table1].columnIndex[columns[k]];
						cout << sql[table1].table[i][index] << " ";
					}
					else {
						int index = sql[table2].columnIndex[columns[k]];
						cout << sql[table2].table[Rindex][index] << " ";
					}
				}
				cout << "\n";
			}
			++rowNum;
		}
	}
	cout << "Printed " << rowNum << " rows from joining " << table1 << " to " << table2 << "\n";
}

void generate_() {
	string trash;
	string Tname;
	string colName;
	string type;
	cin >> trash >> Tname >> type;
	cin >> trash;
	cin >> trash >> colName;
	auto iter = sql.find(Tname);
	if (iter == sql.end()) {
		cout << "Error during GENERATE: " << Tname << " does not name a table in the database\n";
		getline(cin, trash);
		return;
	}
	auto iterCol = find(iter->second.columnName.begin(), iter->second.columnName.end(), colName);
	size_t indexCol = distance(iter->second.columnName.begin(), iterCol);
	if (iterCol == iter->second.columnName.end()) {
		cout << "Error during GENERATE: " << colName << " does not name a column in " << Tname << "\n";
		getline(cin, trash);
		return;
	}
	if (!iter->second.bst.empty()) {
		iter->second.bst.clear();
	}
	if (!iter->second.hash.empty()) {
		iter->second.hash.clear();
	}
	iter->second.hashed = colName;
	if (type == "hash") {
		for (size_t i = 0; i < iter->second.table.size(); ++i) {
			iter->second.hash.emplace(iter->second.table[i][indexCol], (int)i);
		}
	}
	else {
		for (size_t i = 0; i < iter->second.table.size(); ++i) {
			iter->second.bst.emplace(iter->second.table[i][indexCol], (int)i);
		}
	}
	cout << "Created " << type << " index for table " << Tname << " on column " << colName << "\n";
}


int main(int argc, char* argv[]) {
	std::ios_base::sync_with_stdio(false);
	cin >> boolalpha;
	cout << boolalpha;
	//cout << "hello world" << endl;
	if (argc > 1) {
		string mode = argv[1];
		if (mode == "-h" || mode == "--help") {
			cout << "To be, or not to be, that is a question.\n";
				exit(0);
		}
		if (mode == "-q" || mode == "--quiet") {
			quiet = true;
		}
	}
	string command;
	do {
		cout << "% ";
		cin >> command;
		if (command[0] == '#') {
			string trash;
			getline(cin, trash);
		}
		else if (command == "CREATE") {
			create();
		}
		else if (command == "REMOVE") {
			remove();
		}
		else if (command == "INSERT") {
			insert();
		}
		else if (command == "PRINT") {
			print();
		}
		else if (command == "DELETE") {
			delete_();
			//string trash;
			//getline(cin, trash);
			//cout << "f*** u b****" << endl;
		}
		else if (command == "JOIN") {
			join();
		}
		else if (command == "GENERATE") {
			generate_();
		}
		else if (command != "QUIT") {
			cout << "Error: unrecognized command\n";
			string trash;
			getline(cin, trash);
		}
	} while (command != "QUIT");

	cout << "Thanks for being silly!\n";
	return 0;
}